# USDF Setup Guide

Instructions for setting up your miner, wallet, and bridge.