# USDFreedomDollar

Mineable $1 crypto for everyone.